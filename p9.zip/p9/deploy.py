import json
import os
from dotenv import load_dotenv #pip install python-dotenv
from web3 import Web3 #pip install web3
from solcx import compile_standard, install_solc #pip install py-solc-x


load_dotenv()


with open("./SimpleStorage.sol", "r") as file:
    simple_storage_file = file.read()


print("Installing Solidity compiler...")
install_solc("0.6.0")


compiled_sol = compile_standard(
    {
        "language": "Solidity",
        "sources": {"SimpleStorage.sol": {"content": simple_storage_file}},
        "settings": {
            "outputSelection": {
                "*": {"*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"]}
            }
        },
    },
    solc_version="0.6.0",
)


with open("compiled_code.json", "w") as file:
    json.dump(compiled_sol, file)


bytecode = compiled_sol["contracts"]["SimpleStorage.sol"]["SimpleStorage"]["evm"]["bytecode"]["object"]
abi = json.loads(compiled_sol["contracts"]["SimpleStorage.sol"]["SimpleStorage"]["metadata"])["output"]["abi"]


w3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
chain_id = 1337  


if not w3.is_connected():
    raise Exception("Web3 is not connected to blockchain!")

print("Connected to blockchain")




my_address = os.getenv("my_address")
private_key = os.getenv("private_key")


SimpleStorage = w3.eth.contract(abi=abi, bytecode=bytecode)
nonce = w3.eth.get_transaction_count(my_address)

transaction = SimpleStorage.constructor().build_transaction({
    "chainId": chain_id,
    "from": my_address,
    "nonce": nonce,
    "gasPrice": w3.eth.gas_price,
})


signed_txn = w3.eth.account.sign_transaction(transaction, private_key=private_key)
print("Deploying contract...")
tx_hash = w3.eth.send_raw_transaction(signed_txn.raw_transaction)

print("Waiting for deployment...")
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
print(f"Contract deployed at: {tx_receipt.contractAddress}")


simple_storage = w3.eth.contract(address=tx_receipt.contractAddress, abi=abi)


print(f"Initial Stored Value: {simple_storage.functions.retrieve().call()}")


store_txn = simple_storage.functions.store(15).build_transaction({
    "chainId": chain_id,
    "from": my_address,
    "nonce": nonce + 1,
    "gasPrice": w3.eth.gas_price,
})

signed_store_txn = w3.eth.account.sign_transaction(store_txn, private_key=private_key)
print("Updating stored value...")
tx_store_hash = w3.eth.send_raw_transaction(signed_store_txn.raw_transaction)
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_store_hash)


print(f"Updated Stored Value: {simple_storage.functions.retrieve().call()}")